const httpStatus = require('http-status');
const catchAsync = require('../utils/catchAsync');
const { generatePasswordService } = require('../services');

const generatePassword = catchAsync(async (req, res) => {
    const passwordAndKey = await generatePasswordService.generatePassword(req.query.limit, req.query.delimiter);
    res.status(httpStatus.OK).send(passwordAndKey);
  });

module.exports = {
  generatePassword
};
