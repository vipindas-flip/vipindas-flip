const express = require('express');
const auth = require('../../middlewares/auth');
const validate = require('../../middlewares/validate');
const userValidation = require('../../validations/user.validation');
const tagSystemController = require('../../controllers/tagSystem.controller');

const router = express.Router();

router
  .route('/')
  .post(auth('tag-system'), tagSystemController.tagSystem)
  .get(auth('get-tagged-system'), tagSystemController.getTaggedSystems);

module.exports = router;

/**
 * @swagger
 * tags:
 *   name: Tag System
 *   description: This route is for various system tagging activities
 */

/**
 * @swagger
 * /taggSystem:   
 *   get:
 *     summary: Get all tagged systems
 *     description: Both admin and users can access this route.
 *     tags: [Tag System]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: tagid
 *         schema:
 *           type: string
 *         description: system tagg id
 *       - in: query
 *         name: teamName
 *         schema:
 *           type: string
 *         description: team name
 *       - in: query
 *         name: sortBy
 *         schema:
 *           type: string
 *         description: sort by query in the form of field:desc/asc (ex. name:asc)
 *       - in: query
 *         name: limit
 *         schema:
 *           type: integer
 *           minimum: 1
 *         default: 10
 *         description: Maximum number of users
 *       - in: query
 *         name: page
 *         schema:
 *           type: integer
 *           minimum: 1
 *           default: 1
 *         description: Page number
 *     responses:
 *       "200":
 *         description: OK
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 results:
 *                   type: array
 *                   items:
 *                     $ref: '#/components/schemas/getTagedUser'
 *                 page:
 *                   type: integer
 *                   example: 1
 *                 limit:
 *                   type: integer
 *                   example: 10
 *                 totalPages:
 *                   type: integer
 *                   example: 1
 *                 totalResults:
 *                   type: integer
 *                   example: 1
 *       "401":
 *         $ref: '#/components/responses/Unauthorized'
 *       "403":
 *         $ref: '#/components/responses/Forbidden'
 * 
 *   post:
 *     summary: Tag system
 *     description: Only admins can tag a system
 *     tags: [Tag System]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - teamName
 *               - teamEmail
 *               - ticketGroup
 *               - ManagerEmail
 *               - systemName
 *               - systemPriority
 *               - taggId
 *               - applicationName
 *             properties:
 *               teamName:
 *                 type: string
 *               teamEmail:
 *                 type: string
 *                 format: email
 *               ticketGroup:
 *                 type: string
 *               ManagerEmail:
 *                  type: string
 *                  format: email
 *               systemName:
 *                 type: string
 *               systemPriority:
 *                 type: string
 *               taggId:
 *                 type: string
 *               applicationName:
 *                  type: string
 *             example:
 *                teamName: linux
 *                teamEmail: linuxadmin@flipkart.com
 *                ticketGroup: 82-infralinux
 *                ManagerEmail: managername@flipkart.com 
 *                systemName: linux system
 *                systemPriority: p1
 *                taggId: 000001
 *                applicationName: infralinux
 *     responses:
 *       "201":
 *         description: Created
 *         content:
 *           application/json:
 *             schema:
 *                $ref: '#/components/schemas/User'
 *       "400":
 *         $ref: '#/components/responses/DuplicateEmail'
 *       "401":
 *         $ref: '#/components/responses/Unauthorized'
 *       "403":
 *         $ref: '#/components/responses/Forbidden'
 */
