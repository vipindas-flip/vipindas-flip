const mongoose = require('mongoose');
const validator = require('validator');
const bcrypt = require('bcryptjs');
const { toJSON, paginate } = require('./plugins');

const tagSystemSchema = mongoose.Schema(
  {
    teamName: {
      type: String,
      required: true,
      trim: true,
    },
    teamEmail: {
      type: String,
      required: true,
      trim: true,
      lowercase: true,
      validate(value) {
        if (!validator.isEmail(value)) {
          throw new Error('Invalid email');
        }
      },
    },
    ticketGroup: {
      type: String,
      required: true,
      trim: true,
    },
    ManagerEmail: { 
        type: String,
        required: true,
        trim: true,
        lowercase: true,
        validate(value) {
          if (!validator.isEmail(value)) {
            throw new Error('Invalid Manager email');
          }
        },
      },
      systemName: {
        type: String,
        required: true,
        trim: true,
      },
      systemPriority: {
        type: String,
        required: true,
        trim: true,
      },
      taggId: {
        type: String,
        required: true,
        unique: true,
        trim: true,
      },
      applicationName: {
        type: String,
        required: true,
        unique: true,
        trim: true,
      },
  },
  {
    timestamps: true,
  }
);

// add plugin that converts mongoose to json
tagSystemSchema.plugin(toJSON);
tagSystemSchema.plugin(paginate);

/**
 * Check if email is taken
 * @param {string} email - The user's email
 * @param {ObjectId} [excludeUserId] - The id of the user to be excluded
 * @returns {Promise<boolean>}
 */
 tagSystemSchema.statics.isEmailTaken = async function (email, excludeUserId) {
  const user = await this.findOne({ email, _id: { $ne: excludeUserId } });
  return !!user;
};

/**
 * Check if application name already exists
 * @param {string} email - The user's email
 * @param {ObjectId} [tagObjId] - The id of the system tag to be excluded
 * @returns {Promise<boolean>}
 */
 tagSystemSchema.statics.isApplicationNameTaken = async function (applicationName, tagObjId) {
    const systemDetails = await this.findOne({ applicationName, _id: { $ne: tagObjId } });
    return !!applicationName;
  };

/**
 * @typedef User
 */
const tagSystem = mongoose.model('tagSystem', tagSystemSchema);

module.exports = tagSystem;
