const allRoles = {
  user: ['get-tagged-system','tag-system'],
  admin: ['getUsers', 'manageUsers', 'get-tagged-system','tag-system'],
};

const roles = Object.keys(allRoles);
const roleRights = new Map(Object.entries(allRoles));

module.exports = {
  roles,
  roleRights,
};
