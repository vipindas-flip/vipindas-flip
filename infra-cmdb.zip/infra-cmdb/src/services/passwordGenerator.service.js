const { getWords } = require('../utils/word_db_1');
const words = getWords();
function getRandomNumber(ceiling) {
    return Math.floor(crypto.getRandomValues(new Uint32Array(1))[0] / (0xffffffff + 1) * ceiling);
};

function getRandomSymbol() {
    const symbols = '0123456789!@#$%&*,.'
    return symbols[Math.floor(Math.random() * symbols.length)];
};

function generatePassphrase(limit, delimiter) {
    let selectedWords = [];

    for (let i = 0; i < limit; i++) {
        selectedWords.push(words[getRandomNumber(words.length)]);
    }

    var Newpassphrase = '';
    if (!!delimiter) {
        Newpassphrase = selectedWords.join(delimiter);
    } else {
        Newpassphrase = selectedWords.slice(0, -1).join(getRandomSymbol()) + getRandomSymbol() + selectedWords.slice(-1);
    }

    var NewpassphraseCopy = Newpassphrase;
    Newpassphrase = Newpassphrase.replace(/o/g, '0').replace(/i/g, '1').replace(/e/g, '3').replace(/a/g, '@');
    
    return ({
        password: Newpassphrase,
        key: NewpassphraseCopy
    });

};
/**
 *  generate password based on the limit provided by the user
 * @param {ObjectId} limit - length of words
 * @param {delimiter} delimiter - defines the separator
 * @returns 
 */

const generatePassword = async (limit, delimiter) => {
    return generatePassphrase(limit, delimiter);

    // console.log("Words = " + getWords())

    // var length = limit,
    // charset = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789",
    // retVal = "";
    // for (var i = 0, n = charset.length; i < length; ++i) {
    // retVal += charset.charAt(Math.floor(Math.random() * n));
    // }
    // return ({
    //     'password': retVal,
    //     'key':'user Key'
    // })
}

module.exports = {
    generatePassword
};
