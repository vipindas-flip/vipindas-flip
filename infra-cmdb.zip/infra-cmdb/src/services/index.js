module.exports.authService = require('./auth.service');
module.exports.emailService = require('./email.service');
module.exports.tokenService = require('./token.service');
module.exports.userService = require('./user.service');
module.exports.tagsystemService = require('./tagsystem.service');
module.exports.generatePasswordService = require('./passwordGenerator.service');
