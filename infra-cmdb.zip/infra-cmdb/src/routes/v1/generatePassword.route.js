const express = require('express');
const auth = require('../../middlewares/auth');
const validate = require('../../middlewares/validate');
const generatePassword = require('../../controllers/passwordGenerator.controller');
const pswGenValidation = require('../../validations/generatePassword.validation');

const router = express.Router();

router
  .route('/')
  .get(validate(pswGenValidation.generatePassword),generatePassword.generatePassword);

module.exports = router;