const Joi = require('joi');

const generatePassword = {
    query: Joi.object().keys({
    limit: Joi.number().required().less(6).greater(2),
    delimiter: Joi.string().optional().allow(null,"").max(1)
  }),
};

module.exports = {
    generatePassword,
  };
  